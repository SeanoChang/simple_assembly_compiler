/* 
The class for constructing the instruction table structure.
Basically, it is the stack to store the op instructions.
*/
#include <iostream>
#include <memory>

#include "InstructionBuffer.h"

InstructionBuffer* InstructionBuffer::uniqueInst = NULL;
std::vector<std::unique_ptr<Instruction<Stmt>>> InstructionBuffer::instBuffer = std::vector<std::unique_ptr<Instruction<Stmt>>>();

InstructionBuffer::InstructionBuffer() {
    instBuffer.reserve(20);
}

InstructionBuffer* InstructionBuffer::getInstructionBuffer() {
    if (uniqueInst == NULL) {
        uniqueInst = new InstructionBuffer();
    }
    return uniqueInst;
}

void InstructionBuffer::addToInstructionBuffer(Stmt* stmt, int loc, std::string label) {
    if(stmt->getOpcode() != 0) {
        std::cout << "Adding instruction to instruction buffer " << stmt->getOperation() << " " << loc << std::endl;
        if(instBuffer.size() == instBuffer.capacity()){
            instBuffer.reserve(instBuffer.capacity() * 2);
        }
        instBuffer.push_back(make_unique<Instruction<Stmt>>(stmt, loc, label));
    }
}

int InstructionBuffer::getInstructionBufferSize() const {
    return instBuffer.size();
}

void InstructionBuffer::printInstructionBuffer() const {
    for (auto& inst: instBuffer) {
        if(inst->getInstructionState() >= 0){
            if(inst->getInstruction() == "Prints"){
                std::cout << inst->getInstruction() << " " << inst->getLabel() << std::endl;
            }
            std::cout << inst->getInstruction() << " " << inst->getInstructionState() <<std::endl;
        }
    }
    std::cout << std::endl;
}
